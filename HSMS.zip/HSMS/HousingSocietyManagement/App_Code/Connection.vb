﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data


Public Class Connection

    Public Sub ConnectionString()

        Dim con As SqlConnection = New sqlconnection()
        con.ConnectionString = "Data Source=SHUBHAM-PC;Initial Catalog=HSMSystem; Integrated Security=True"
        con.Open()

        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from Customers", con)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        'DataGridView1.DataSource = ds.Tables(0)

    End Sub

End Class
