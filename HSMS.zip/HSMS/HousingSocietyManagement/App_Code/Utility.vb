﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Net
Imports System.Net.Mail
''' <summary>6
''' 
''' Summary description for Utility
''' </summary>
Public Class Utility
    '
    ' TODO: Add constructor logic here
    '
    Public Sub New()
    End Sub
    Public Function sendMail(ByVal from As [String], ByVal [to] As [String], ByVal pass As [String], ByVal subject As [String], ByVal body As [String]) As [String]

        Dim msg__1 As [String] = "Mail Send Successfully"

        Try

            Dim Msg__2 As New MailMessage()
            ' Sender e-mail address.
            Msg__2.From = New MailAddress(from)
            ' Recipient e-mail address.
            Msg__2.[To].Add([to])
            Msg__2.Subject = subject
            Msg__2.Body = body
            ' your remote SMTP server IP.

            Dim smtp As New SmtpClient()

            smtp.Host = "smtp.mail.yahoo.com"
            smtp.Port = 587
            smtp.Credentials = New System.Net.NetworkCredential(from, pass)
            smtp.EnableSsl = True
            smtp.Send(Msg__2)

            Msg__2 = Nothing

        Catch ex As Exception

            msg__1 = "Error While Sending Mail"

        End Try

        Return msg__1

    End Function

End Class
