﻿
Partial Class AdminLogin
    Inherits System.Web.UI.Page

   

    
    
End Class
