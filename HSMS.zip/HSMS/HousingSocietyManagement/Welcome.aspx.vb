﻿
Partial Class Welcome
    Inherits System.Web.UI.Page

End Class
