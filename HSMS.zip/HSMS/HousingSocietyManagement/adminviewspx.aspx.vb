﻿
Partial Class adminviewspx
    Inherits System.Web.UI.Page

End Class
